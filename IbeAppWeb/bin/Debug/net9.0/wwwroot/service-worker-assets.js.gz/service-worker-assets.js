self.assetsManifest = {
  "version": "msv6VHSb",
  "assets": [
    {
      "hash": "sha256-f+LC/qeJq2N1Sd1a5qUxFBctUniZ6keshB5Sxe4Z+rg=",
      "url": "IbeAppWeb.styles.css"
    },
    {
      "hash": "sha256-kJXKqRCleT/Jk1wJUhUu24r2LAA7IWVYmdoENizE38M=",
      "url": "_content/Microsoft.AspNetCore.Components.WebAssembly.Authentication/AuthenticationService.js"
    },
    {
      "hash": "sha256-8nv+wqmwV0IMxrhPBpv6vQ4ItRwZhfyS/731Bk6Uukk=",
      "url": "_content/Microsoft.Authentication.WebAssembly.Msal/AuthenticationService.js"
    },
    {
      "hash": "sha256-V/yAlKw4EDg0Y0P1iSghzTi2zHiFJWVTl9x83RroAE0=",
      "url": "_content/Syncfusion.Blazor.Buttons/scripts/sf-floating-action-button.min.js"
    },
    {
      "hash": "sha256-6VexFpPZQN6pAcx6ug2tONgN+95D6ormc022HJHniDg=",
      "url": "_content/Syncfusion.Blazor.Buttons/scripts/sf-speeddial.min.js"
    },
    {
      "hash": "sha256-LPZFCuVm0VXn/D2gNTj273hEPh0Ggeyhh73rZTp7Yew=",
      "url": "_content/Syncfusion.Blazor.Calendars/scripts/sf-calendar.min.js"
    },
    {
      "hash": "sha256-oz+VIKdDBtsPNiEnAPnbY8mOXIuJMkLN+mUr1IqlCq0=",
      "url": "_content/Syncfusion.Blazor.Calendars/scripts/sf-datepicker.min.js"
    },
    {
      "hash": "sha256-oHViSI5R2eyEdTU3hieK+xnY+0UMAqLK0m6MKKVSljo=",
      "url": "_content/Syncfusion.Blazor.Calendars/scripts/sf-daterangepicker.min.js"
    },
    {
      "hash": "sha256-4Yk9wsahigFQs4JMifSEki0QPJ7Zptm1+3RA8bpeduU=",
      "url": "_content/Syncfusion.Blazor.Calendars/scripts/sf-timepicker.min.js"
    },
    {
      "hash": "sha256-1vilJfPf3+uGoYi1douM75iTfu/8MsbSSECH5MN15cA=",
      "url": "_content/Syncfusion.Blazor.Core/scripts/popup.min.js"
    },
    {
      "hash": "sha256-pKr0AoVoemoP7bIAuaF6lO0sKFhGydmxKVIq1Vi+Z/A=",
      "url": "_content/Syncfusion.Blazor.Core/scripts/popupsbase.min.js"
    },
    {
      "hash": "sha256-JFefsNh2yTWAI9cPbT81TcHlI0G/ymn/l+QPTu5l/Eo=",
      "url": "_content/Syncfusion.Blazor.Core/scripts/sf-svg-export.min.js"
    },
    {
      "hash": "sha256-Copw0b5W1Ixp52X80cARk/2aZMy07y3JSBIybAnfcAQ=",
      "url": "_content/Syncfusion.Blazor.Core/scripts/svgbase.min.js"
    },
    {
      "hash": "sha256-FJB65VSqOs+S7g4TmNF74iC165FJxiRrFARJp7KD6oU=",
      "url": "_content/Syncfusion.Blazor.Core/scripts/syncfusion-blazor-base.min.js"
    },
    {
      "hash": "sha256-xJNIL0efaeK/NkvJnSIRd+7PKi+p/TY0rqkqs5qttoY=",
      "url": "_content/Syncfusion.Blazor.Core/scripts/syncfusion-blazor.min.js"
    },
    {
      "hash": "sha256-B8zwnvK60ijeNNoCaiDbjR50r3bLA+DaXfbUL4/ELWs=",
      "url": "_content/Syncfusion.Blazor.Data/scripts/data.min.js"
    },
    {
      "hash": "sha256-z/rw6jihCkroO2rcBp74Z4oH+2qSld9Euo+9FC1xQyM=",
      "url": "_content/Syncfusion.Blazor.DropDowns/scripts/sf-dropdownlist.min.js"
    },
    {
      "hash": "sha256-ue9c3MCr7RaQpo3814im9gjOqsUswvPlfHJny3HIzB8=",
      "url": "_content/Syncfusion.Blazor.DropDowns/scripts/sf-listbox.min.js"
    },
    {
      "hash": "sha256-1v3a8b2pXjqvrDLG3w4MH6b4WrbSU1prz1kzfCdSEDU=",
      "url": "_content/Syncfusion.Blazor.DropDowns/scripts/sf-mention.min.js"
    },
    {
      "hash": "sha256-Xe2/r6J+T4MPOE64QOuvYB7OIQX2DxAvOClOzeeDxFw=",
      "url": "_content/Syncfusion.Blazor.DropDowns/scripts/sf-multiselect.min.js"
    },
    {
      "hash": "sha256-iWbioLjvVYTe3r7PkZKrAVWR5D4ghUGCw0DM/T+4nNA=",
      "url": "_content/Syncfusion.Blazor.DropDowns/scripts/sortable.min.js"
    },
    {
      "hash": "sha256-0LgFn+1Bq5L9WMsYwKJnby927g900EDEARv78AkJ3F0=",
      "url": "_content/Syncfusion.Blazor.Grid/scripts/sf-grid.min.js"
    },
    {
      "hash": "sha256-HQNkGSPPm0YkEET2gXZMyWmZDFPNkDSkJntsVpFWsIU=",
      "url": "_content/Syncfusion.Blazor.Inputs/scripts/sf-colorpicker.min.js"
    },
    {
      "hash": "sha256-XSbdTyRS2zVN8qs2hS324QA4atOtGRRIAV56CwieGmI=",
      "url": "_content/Syncfusion.Blazor.Inputs/scripts/sf-maskedtextbox.min.js"
    },
    {
      "hash": "sha256-FWgnt1hYUUwIul/rwe1ylAnuJzB4U3i8AH2YOSx31cU=",
      "url": "_content/Syncfusion.Blazor.Inputs/scripts/sf-numerictextbox.min.js"
    },
    {
      "hash": "sha256-Qe4Qy/dW8tDMc9QGpJZFtStMPLwPo3To0t8MUaHRvrI=",
      "url": "_content/Syncfusion.Blazor.Inputs/scripts/sf-otp-input.min.js"
    },
    {
      "hash": "sha256-GZVu/zOlYuMI4gtGcFTbAQrv7eyQkLlEIFFNRUA5i54=",
      "url": "_content/Syncfusion.Blazor.Inputs/scripts/sf-rating.min.js"
    },
    {
      "hash": "sha256-v29jC03sdp0c0NxydF6Th9JRRfBXtmljLj/z4h43v/k=",
      "url": "_content/Syncfusion.Blazor.Inputs/scripts/sf-signature.min.js"
    },
    {
      "hash": "sha256-/WDVKBhD80qhEFk9EmPJEW8dQN2g5sYrrE+9uUggQNc=",
      "url": "_content/Syncfusion.Blazor.Inputs/scripts/sf-slider.min.js"
    },
    {
      "hash": "sha256-K3Jx+/1WU7MvViG/OJCtf7KxHmWwmFuBsZv4xHvrpng=",
      "url": "_content/Syncfusion.Blazor.Inputs/scripts/sf-textarea.min.js"
    },
    {
      "hash": "sha256-mUnC3yT/dw6310zVbUw6xSfRWbW+q2VwhTCygZDkTrU=",
      "url": "_content/Syncfusion.Blazor.Inputs/scripts/sf-textbox.min.js"
    },
    {
      "hash": "sha256-GTtn3+siuYvZGVxYgfPpxh98vbjtW1tpKq1u5ROusa0=",
      "url": "_content/Syncfusion.Blazor.Inputs/scripts/sf-uploader.min.js"
    },
    {
      "hash": "sha256-b4vus46X0WqZdoNOovxx3Lx8i0At7CJGXHbhi3xSG6g=",
      "url": "_content/Syncfusion.Blazor.Lists/scripts/sf-listview.min.js"
    },
    {
      "hash": "sha256-zqHuH+J1FbdWp6GdmTwdDVGmSGrzMLYZGZPXbL2D5tw=",
      "url": "_content/Syncfusion.Blazor.Navigations/scripts/navigationsbase.min.js"
    },
    {
      "hash": "sha256-h7b9gwmjbUtHZwR8dLV/sB8TQuz5WYBIVozMw17HJY4=",
      "url": "_content/Syncfusion.Blazor.Navigations/scripts/sf-accordion.min.js"
    },
    {
      "hash": "sha256-IDu3ej0QFHxfrUVFHx4Ype2rXhdhasvR/JgyA6A5k+U=",
      "url": "_content/Syncfusion.Blazor.Navigations/scripts/sf-breadcrumb.min.js"
    },
    {
      "hash": "sha256-wLPjLkXjfH2wSAUJg+jR4fY7ga3lZxz80TyrQjMbQSE=",
      "url": "_content/Syncfusion.Blazor.Navigations/scripts/sf-carousel.min.js"
    },
    {
      "hash": "sha256-NbvvfgF6XzHXsqQVAFzpzkWu/DL5+s3yzrR5BCZLXWI=",
      "url": "_content/Syncfusion.Blazor.Navigations/scripts/sf-contextmenu.min.js"
    },
    {
      "hash": "sha256-sX57k3EUb4UWxnmwM+h3gHa3GJreiElMkh+EKzQUwk8=",
      "url": "_content/Syncfusion.Blazor.Navigations/scripts/sf-dropdowntree.min.js"
    },
    {
      "hash": "sha256-HhDaITwhKLPRNgIJVJXSbgJiqd2NjsFduAX5assOk/M=",
      "url": "_content/Syncfusion.Blazor.Navigations/scripts/sf-menu.min.js"
    },
    {
      "hash": "sha256-9IBYxtbX0MRG1kaAHNitA1OmPmB7BsBHs1cvvPv1PxE=",
      "url": "_content/Syncfusion.Blazor.Navigations/scripts/sf-pager.min.js"
    },
    {
      "hash": "sha256-zwZX5yP1WM5GQg9FSuqD2DmliaH/oNelQP2PE6iTGgI=",
      "url": "_content/Syncfusion.Blazor.Navigations/scripts/sf-sidebar.min.js"
    },
    {
      "hash": "sha256-iyUB+HXzsNcnqxPNzvu0VYMXg1IP13dKDXOE61TPnPE=",
      "url": "_content/Syncfusion.Blazor.Navigations/scripts/sf-stepper.min.js"
    },
    {
      "hash": "sha256-1QPKcCxfCRuVYGP9rm1J3hK1mePPJXG14qdZlYFqZ5s=",
      "url": "_content/Syncfusion.Blazor.Navigations/scripts/sf-tab.min.js"
    },
    {
      "hash": "sha256-3jq4Ec4yFVQISLhi/8WXwV+HE2lwTMoQ0nT7LDqO88M=",
      "url": "_content/Syncfusion.Blazor.Navigations/scripts/sf-toolbar.min.js"
    },
    {
      "hash": "sha256-wjNeOQW8caBjEFfptxvwRKBC4z1GHbi5wS9R654eXUw=",
      "url": "_content/Syncfusion.Blazor.Navigations/scripts/sf-treeview.min.js"
    },
    {
      "hash": "sha256-WBjrj+YG5/rroh1oote/U/tl2+WA1CJP3oZHtEQeXuc=",
      "url": "_content/Syncfusion.Blazor.Notifications/scripts/sf-toast.min.js"
    },
    {
      "hash": "sha256-rV8ZOGlb/VTwNyTU/bsvhEStHhrCBEwC04+gUp/LOwI=",
      "url": "_content/Syncfusion.Blazor.Popups/scripts/sf-dialog.min.js"
    },
    {
      "hash": "sha256-zofY/jGva84JKmEKqjrmqAHArcPazcFfwXRwMc+v+6I=",
      "url": "_content/Syncfusion.Blazor.Popups/scripts/sf-tooltip.min.js"
    },
    {
      "hash": "sha256-DRfBtiEhCnBPq+e4cekZcJrqoU7Sx4qXqLvAX21gkng=",
      "url": "_content/Syncfusion.Blazor.Spinner/scripts/sf-spinner.min.js"
    },
    {
      "hash": "sha256-MEcHBaSfZ4Xmk9JVLc2OClioPglKqwdlqSJwgSJ2w/c=",
      "url": "_content/Syncfusion.Blazor.Spinner/scripts/spinner.min.js"
    },
    {
      "hash": "sha256-uXeXlQCPK48S+8YUgTaEBGFz6rKKFQi/3FgLsRCBlsA=",
      "url": "_content/Syncfusion.Blazor.SplitButtons/scripts/sf-drop-down-button.min.js"
    },
    {
      "hash": "sha256-0uqOB+fcF59Wb7hmW6p2hEWfvxC00U9Ite36CS6TsBs=",
      "url": "_content/Syncfusion.Blazor.SplitButtons/scripts/splitbuttonsbase.min.js"
    },
    {
      "hash": "sha256-RkrjlvTim4vMVcp6WxKgG65UPFYWa9TL8l1P5kHZ+Qg=",
      "url": "_content/Syncfusion.Blazor.Themes/bds-dark-lite.css"
    },
    {
      "hash": "sha256-ZMFQ2iinthto4DgwE4/gxEK+0wFvLxA3tAYYlVnDEfM=",
      "url": "_content/Syncfusion.Blazor.Themes/bds-dark.css"
    },
    {
      "hash": "sha256-B0pPPnGbDxnY5q240sPzPDBc6xZeYh7jDMXQo4uYNHQ=",
      "url": "_content/Syncfusion.Blazor.Themes/bds-lite.css"
    },
    {
      "hash": "sha256-rtu1kHHTXTMBnPxfYHru9c/8dJkYHiGrPYR9KWOuB/4=",
      "url": "_content/Syncfusion.Blazor.Themes/bds.css"
    },
    {
      "hash": "sha256-NHhnSIaTl495Z8E3y1GQ1ya7UOi7/NBLOcw6ymCGh+k=",
      "url": "_content/Syncfusion.Blazor.Themes/bootstrap-dark-lite.css"
    },
    {
      "hash": "sha256-JF/Z27/Haw77MViMyl2ji+mj1UT5bMQ8db4wIwUWmxI=",
      "url": "_content/Syncfusion.Blazor.Themes/bootstrap-dark.css"
    },
    {
      "hash": "sha256-MAcGyNkh9KKR7Y5llx0S/flvS8RL85+7L7SL/KqS/so=",
      "url": "_content/Syncfusion.Blazor.Themes/bootstrap-lite.css"
    },
    {
      "hash": "sha256-g3AekL97DFVbIkzGXsBOwlZYmDWNBnuSmpnOwMcVgEg=",
      "url": "_content/Syncfusion.Blazor.Themes/bootstrap.css"
    },
    {
      "hash": "sha256-SPlCAPm2PwJdxLfozeefbgvqow77zj1gZgey5BHGxaU=",
      "url": "_content/Syncfusion.Blazor.Themes/bootstrap4-lite.css"
    },
    {
      "hash": "sha256-85CaR8eCo7/E78vL+5IP9TBy+7hKJWtehro4kLviaHA=",
      "url": "_content/Syncfusion.Blazor.Themes/bootstrap4.css"
    },
    {
      "hash": "sha256-d6q/3a92T1RFyulpqUGuJ5o+lIBef+Ap4gAFaW55poA=",
      "url": "_content/Syncfusion.Blazor.Themes/bootstrap5-dark-lite.css"
    },
    {
      "hash": "sha256-C5ALEQxbAe6JfMHqDWrAtLLt5piQpFHQG1NkUXtlJnY=",
      "url": "_content/Syncfusion.Blazor.Themes/bootstrap5-dark.css"
    },
    {
      "hash": "sha256-BnVm+NlcxIa8Io1VEahUjiYEFCFxemPrCDIyC+t7IWQ=",
      "url": "_content/Syncfusion.Blazor.Themes/bootstrap5-lite.css"
    },
    {
      "hash": "sha256-OYvosFT/1LQM76UcDyhMlEGHu3y8/24EKqEm7YRrP2o=",
      "url": "_content/Syncfusion.Blazor.Themes/bootstrap5.3-dark-lite.css"
    },
    {
      "hash": "sha256-CIl8qXTzuiWLsk0sn8RHIKQPQLjoQhPNTWL8h4+h+is=",
      "url": "_content/Syncfusion.Blazor.Themes/bootstrap5.3-dark.css"
    },
    {
      "hash": "sha256-BjeysorFwtujEH1/2hnJgX2zRoyTH2cSiDUeoGbPWio=",
      "url": "_content/Syncfusion.Blazor.Themes/bootstrap5.3-lite.css"
    },
    {
      "hash": "sha256-Lt1ZC3f+/D2o3zV/tdDVw1RrkcWfoda8nH7SyLE5iuE=",
      "url": "_content/Syncfusion.Blazor.Themes/bootstrap5.3.css"
    },
    {
      "hash": "sha256-h2NDhg09jDfBCpnyoD3ifwUrh7DAFKmQ8JleozDMq74=",
      "url": "_content/Syncfusion.Blazor.Themes/bootstrap5.css"
    },
    {
      "hash": "sha256-dsAQ8Eb+fesgjayU9fDRY1Q6QQI96Emdm+qj20wVTJo=",
      "url": "_content/Syncfusion.Blazor.Themes/customized/material-dark.css"
    },
    {
      "hash": "sha256-5wjKvLyXRao0i96Z+W73E95asiTHKVPwmYESbeREqqI=",
      "url": "_content/Syncfusion.Blazor.Themes/customized/material.css"
    },
    {
      "hash": "sha256-VjyZ6cd5PUouQCE0Xj1tZ0z8Kfcs3GmlDiaQu7yAAn4=",
      "url": "_content/Syncfusion.Blazor.Themes/customized/tailwind-dark.css"
    },
    {
      "hash": "sha256-5ggu8Vy/oosxhxjJ4tkJbvzM9Ad4G2xGZ4NiZQq70rw=",
      "url": "_content/Syncfusion.Blazor.Themes/customized/tailwind.css"
    },
    {
      "hash": "sha256-Cjri7X0CO2L8jmS04TyJTOFtvVVKYmE65sfg6W2ywCo=",
      "url": "_content/Syncfusion.Blazor.Themes/fabric-dark-lite.css"
    },
    {
      "hash": "sha256-x9zbxP1dgOk6GUvQcMQvtdUOeeAA181dk1tKCM5Ux7o=",
      "url": "_content/Syncfusion.Blazor.Themes/fabric-dark.css"
    },
    {
      "hash": "sha256-FT8p/i6ws+LdiqTyxwftjUtRDzrWENxVAhn+CO1R5Vg=",
      "url": "_content/Syncfusion.Blazor.Themes/fabric-lite.css"
    },
    {
      "hash": "sha256-EymIWA7HWaDSqUvBTZ91keWcWkZBY0SXLQlMa2hB7qc=",
      "url": "_content/Syncfusion.Blazor.Themes/fabric.css"
    },
    {
      "hash": "sha256-xSEk6nbPsrmzpnu1R6X69F8QwaQfrepWo1l6sDIMsqc=",
      "url": "_content/Syncfusion.Blazor.Themes/fluent-dark-lite.css"
    },
    {
      "hash": "sha256-ZhkHdP0fceXTUOF7dowi6BJoS0ULmRazuqls5EK053U=",
      "url": "_content/Syncfusion.Blazor.Themes/fluent-dark.css"
    },
    {
      "hash": "sha256-jGiNSTAM+ABOvliD0qZRjEciIhEXLASxbfS5ge2x/HU=",
      "url": "_content/Syncfusion.Blazor.Themes/fluent-lite.css"
    },
    {
      "hash": "sha256-OuBwSOnfBhyw4NTMtOf+4C4gU9TaEoxfG38kicPihqA=",
      "url": "_content/Syncfusion.Blazor.Themes/fluent.css"
    },
    {
      "hash": "sha256-A2/Pe2w9PVg1He0JlcEgOMV4JmKBc/yfn50C2XWSGvA=",
      "url": "_content/Syncfusion.Blazor.Themes/fluent2-dark-lite.css"
    },
    {
      "hash": "sha256-PBJeNxiDIWQjVCxBGovaUWoZrMIgQvK3sZSQuOD+gi0=",
      "url": "_content/Syncfusion.Blazor.Themes/fluent2-dark.css"
    },
    {
      "hash": "sha256-aXk3Z4eYsipqorNjykTZcPjKzke/qQyVBmqHmLGbNQw=",
      "url": "_content/Syncfusion.Blazor.Themes/fluent2-highcontrast-lite.css"
    },
    {
      "hash": "sha256-fmllAfi7Ku5mziQ+85gm6vuTnEBpypP3JtaIzFTMzXU=",
      "url": "_content/Syncfusion.Blazor.Themes/fluent2-highcontrast.css"
    },
    {
      "hash": "sha256-GIAI6nyV6UkT5zdRi18fZduogAyEk6AopVOwCosLHjw=",
      "url": "_content/Syncfusion.Blazor.Themes/fluent2-lite.css"
    },
    {
      "hash": "sha256-kgSHDttwlniMxQlh7K+YwjbOCdfrVZiJyOTQjTo66Y0=",
      "url": "_content/Syncfusion.Blazor.Themes/fluent2.css"
    },
    {
      "hash": "sha256-6SQ31f1xTZ+NgqZM6XPuhXsa/4sCVS2rgKfjxTgygDI=",
      "url": "_content/Syncfusion.Blazor.Themes/highcontrast-lite.css"
    },
    {
      "hash": "sha256-mILXgNQv4ak69Vi/m1RJqOlShEhhpsSvmovxq4YIY0A=",
      "url": "_content/Syncfusion.Blazor.Themes/highcontrast.css"
    },
    {
      "hash": "sha256-orP2DRIYeBWbsXAwxRecV4W1vNXb+6IH78nSfv8qXMQ=",
      "url": "_content/Syncfusion.Blazor.Themes/material-dark-lite.css"
    },
    {
      "hash": "sha256-w/0sGWqHOclzswQP4sIfkFZw33eewHwBj+UCe8E40Ag=",
      "url": "_content/Syncfusion.Blazor.Themes/material-dark.css"
    },
    {
      "hash": "sha256-WWRJiF8dVSEv5T/zh2zZHBGVCd4kTz4H4t9P2yMamyE=",
      "url": "_content/Syncfusion.Blazor.Themes/material-lite.css"
    },
    {
      "hash": "sha256-qN2nQBWqc+gmdogSJpu7NF7ZDCetNCEQo+gCmxJPxHc=",
      "url": "_content/Syncfusion.Blazor.Themes/material.css"
    },
    {
      "hash": "sha256-9xmY60fEyhLg7D4ShDlKHsGkw+ds2qL5/vREBsJRI4o=",
      "url": "_content/Syncfusion.Blazor.Themes/material3-dark-lite.css"
    },
    {
      "hash": "sha256-vApno9YBwIYRctPup7ADw0WM9MeyDxFrXu5MeA1Qids=",
      "url": "_content/Syncfusion.Blazor.Themes/material3-dark.css"
    },
    {
      "hash": "sha256-jgxDCKiStY0lytUTTWz0UAZGWIN2sXrX9oXjGauDeuY=",
      "url": "_content/Syncfusion.Blazor.Themes/material3-lite.css"
    },
    {
      "hash": "sha256-+o3G4Mo7aG1sB+biGLVJ/Q+9JHkwMw6ADLQ/5qIvV/g=",
      "url": "_content/Syncfusion.Blazor.Themes/material3.css"
    },
    {
      "hash": "sha256-Ir6nGYu1yLb13HN2tfEQFJlCAiNY+cJr/MsRQGu7ed4=",
      "url": "_content/Syncfusion.Blazor.Themes/tailwind-dark-lite.css"
    },
    {
      "hash": "sha256-IJVZVNd99wW+jvEBlUe1EOO1yY9TQbbStWFLEvn7U/w=",
      "url": "_content/Syncfusion.Blazor.Themes/tailwind-dark.css"
    },
    {
      "hash": "sha256-Jbh1Qon0wHA+cC0Psqn3fEFyHX3ehDz77ry6KNk3kQU=",
      "url": "_content/Syncfusion.Blazor.Themes/tailwind-lite.css"
    },
    {
      "hash": "sha256-dYIL5tkSUscJmaOFI9E0VJH4b8iJAORp3cxJMfUKYrs=",
      "url": "_content/Syncfusion.Blazor.Themes/tailwind.css"
    },
    {
      "hash": "sha256-pDok7Qi8EA2J3NKwM2Rq4GHlOZqx+32Boui78EubaaI=",
      "url": "_content/Syncfusion.Blazor.Themes/tailwind3-dark-lite.css"
    },
    {
      "hash": "sha256-UIHLNcd+c1wW2hk0zgO/IW/3jJ9gzjrBkLAWRPwIFuo=",
      "url": "_content/Syncfusion.Blazor.Themes/tailwind3-dark.css"
    },
    {
      "hash": "sha256-pgrE/f+mcU3ai4mEzDHKm3/LnLXE06HFjucCUmTP9as=",
      "url": "_content/Syncfusion.Blazor.Themes/tailwind3-lite.css"
    },
    {
      "hash": "sha256-Bg1yciQKh8y3Ff6+vsq5lvtySZrVbRFyimCzgWsHhj4=",
      "url": "_content/Syncfusion.Blazor.Themes/tailwind3.css"
    },
    {
      "hash": "sha256-kkHZx0ev4+bzz9Jhnkb2dJ9XnVdpNbuo3ip+wAPzPII=",
      "url": "_framework/IbeAppWeb.iv4f0yrmik.wasm"
    },
    {
      "hash": "sha256-n9nvSg5upG4/eCGEtchRXMnJzlS3Yzui13CBNy7izps=",
      "url": "_framework/IbeAppWeb.jnlwcil5e5.pdb"
    },
    {
      "hash": "sha256-tckgv/MbZGhlQfELwFmF6c8AHefXpinSSGgVkwYNK64=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.da83xzpz5r.wasm"
    },
    {
      "hash": "sha256-yxXd/br/k6dt4q3WfIfpkOpIZ0Cz2VY+7Go63ZeGcTY=",
      "url": "_framework/Microsoft.AspNetCore.Components.Authorization.boi5khnd47.wasm"
    },
    {
      "hash": "sha256-ptQ/S1bZkXB+KSMcXrzvNNGsZKvlpvT9eEEl5AZnsBU=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.qji3ksdopo.wasm"
    },
    {
      "hash": "sha256-V3zeyDpLQt5/C5nTnBqYLD6mj4qnmgVMy9LZxN94Kgw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.ns1lctei4w.wasm"
    },
    {
      "hash": "sha256-icgNbthLSExrM1QJ/H0Z43NPwlG6exF9G7PthyodXW4=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.Authentication.p0br4hr514.wasm"
    },
    {
      "hash": "sha256-JOecUyFY5LH5Ac/aS4GR6lcugK/Gq+yc54PvybHGKtA=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.soaj85mrfq.wasm"
    },
    {
      "hash": "sha256-2Vz45dtNjFTXSkiqYQg0Pa4U2MxnfB8sdZh5eqjv7BM=",
      "url": "_framework/Microsoft.AspNetCore.Components.vmzb2angnn.wasm"
    },
    {
      "hash": "sha256-9arpMM6z79R0n6nISEeLvvoWH++2nJ61Q4k++VIz8do=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.1xd6vo83cv.wasm"
    },
    {
      "hash": "sha256-E0vql31dz+XQrspz5IPWdhKbGDQMNuQda3WI+vTA3cA=",
      "url": "_framework/Microsoft.Authentication.WebAssembly.Msal.do8siqebch.wasm"
    },
    {
      "hash": "sha256-9uB/7IFSiKE1yWAQ/EFaS3ub/zf5RJXVK6CMmA7mxhY=",
      "url": "_framework/Microsoft.CSharp.qzjvm9hz38.wasm"
    },
    {
      "hash": "sha256-tFbO+EOloOcq9CVfgaBS5UXQGiGDqw7EHCzyYnzLLUU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.kw6zdn2hre.wasm"
    },
    {
      "hash": "sha256-GSG6+BsFH2r1hLdbN5UzBTPcN7BLg3T3aY8rdFVWPJo=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.ved8dbz2is.wasm"
    },
    {
      "hash": "sha256-Tes3PpZnhlFELJ4sR5mk3LIBSBgSVxaOtm6Stta0RkU=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.t8hgoms9l8.wasm"
    },
    {
      "hash": "sha256-X8yu6Be+ZHHzhDFDdP9RXu+aMsQKscEedJsYUzy2QII=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.d1nka2rlr8.wasm"
    },
    {
      "hash": "sha256-PrC+IowUjQXEpQrCwiBsz7jex1/PghKoVx6dBviJVk0=",
      "url": "_framework/Microsoft.Extensions.Configuration.u53zhhc46z.wasm"
    },
    {
      "hash": "sha256-npQU9Z8aEiXs0oV0uIqqHDN/aChnciTYfWzbp9IfY/w=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.auqecwqpl6.wasm"
    },
    {
      "hash": "sha256-lemV4Or052KZxgSAj3apn5nNQywSyUWl+2Fan98Bl+4=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.b4d8qm7pau.wasm"
    },
    {
      "hash": "sha256-XK4yjhBp9ksL7h6/ebqAR1HCPn2J3GpEbf9c57HcAI8=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.kqqw7ug7ce.wasm"
    },
    {
      "hash": "sha256-it/ygGigzRU3ywKNWGR0Gl2nsIrJWHV/HC4P5v37uQk=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.mh53tttw45.wasm"
    },
    {
      "hash": "sha256-qIytzULqOsu5wQ9kRbESlZbqf91VCam4aH1AEY0B8dI=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.0i562wdyma.wasm"
    },
    {
      "hash": "sha256-QXqjRpmXblZV5MMeJZFa3Mu4tE3kl+4rj0IQLUagaqk=",
      "url": "_framework/Microsoft.Extensions.Logging.96umgmlbmk.wasm"
    },
    {
      "hash": "sha256-KwwLdtp/WV66kdUDadHqq/t2a1K37aZTZfQ9dXMZHwI=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.l8y69abh7s.wasm"
    },
    {
      "hash": "sha256-rPwXGCJV2b2qbHrWMZjOHUDtmkMjf5M9ecjgbq3vlCc=",
      "url": "_framework/Microsoft.Extensions.Options.83qdyvwc4v.wasm"
    },
    {
      "hash": "sha256-c3q6DqetjnVCASwVQf1HEJPSXiGtOzmzRbNsXrQRnpw=",
      "url": "_framework/Microsoft.Extensions.Primitives.j8wpr8jzql.wasm"
    },
    {
      "hash": "sha256-w+WvmTYZ9xv2XDrEoF7buW47/o7dUeKdnYWKUgyFEkU=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.lao5cp8gqq.wasm"
    },
    {
      "hash": "sha256-KUgYboUywTiNc2KAn4+PwXUpsvPc+qyNcWlyUHCiuUA=",
      "url": "_framework/Microsoft.JSInterop.fehvqxd8e9.wasm"
    },
    {
      "hash": "sha256-tT8Mx7IXGkD6vZZAtEi9ZzXf+A2nPkCn9cStfF49D8w=",
      "url": "_framework/Microsoft.VisualBasic.Core.790ssxljcz.wasm"
    },
    {
      "hash": "sha256-mF3L2/zWdzCiZgxEqWZq47WPANCts8RfZuGD/Q+uuX8=",
      "url": "_framework/Microsoft.VisualBasic.o05ci7346e.wasm"
    },
    {
      "hash": "sha256-EiWyemclMi1PgUArdIfN4wrpSvL30PbdGpW3hK7Kujg=",
      "url": "_framework/Microsoft.Win32.Primitives.iclgtmwg3j.wasm"
    },
    {
      "hash": "sha256-5E1OW2jOP0sC2xDrg1wPVU+AT40zGS6wfHzblMd1JmY=",
      "url": "_framework/Microsoft.Win32.Registry.ozmyxl3pzt.wasm"
    },
    {
      "hash": "sha256-JxoiA9aVL2Ey84rA38avEpkT5U1sNKI29UQIrSe9BjI=",
      "url": "_framework/Syncfusion.Blazor.Buttons.zx2l0i1ykv.wasm"
    },
    {
      "hash": "sha256-Y6YRfUep82CHHHi8QMgPlj0sD0aK94OS+NtzyZrCxJU=",
      "url": "_framework/Syncfusion.Blazor.Calendars.5ylyithzdd.wasm"
    },
    {
      "hash": "sha256-riufRwxL/QBlEJysWU6drl9JnMqiOLaqtvcnqCNfKrM=",
      "url": "_framework/Syncfusion.Blazor.Core.usqg8uo6wu.wasm"
    },
    {
      "hash": "sha256-GAtqTt0fQIt9R+qo1+iopEW9OyCWYV0Sa2TqCYAvsnY=",
      "url": "_framework/Syncfusion.Blazor.Data.s7kfrnobw4.wasm"
    },
    {
      "hash": "sha256-MNUil+xlBJvbLUP6wCEb9IOPXNudamnvpTOuUIXTxCU=",
      "url": "_framework/Syncfusion.Blazor.DropDowns.g869vxs159.wasm"
    },
    {
      "hash": "sha256-D895do245MY3hyGGiFid6yG5mmgnkE2CcdzK+M+gFLw=",
      "url": "_framework/Syncfusion.Blazor.Grids.7e10k5om1c.wasm"
    },
    {
      "hash": "sha256-BDdP3WOe+FDm3EHTJ4Ome5Vg+sDxBZxRICZ0zS/Fe8Y=",
      "url": "_framework/Syncfusion.Blazor.Inputs.c0v0s4g42b.wasm"
    },
    {
      "hash": "sha256-rLDdbzbE4R/OnHeEjwBWa7riBJroh/Lj59thtSaRFDo=",
      "url": "_framework/Syncfusion.Blazor.Lists.seghmfrvy4.wasm"
    },
    {
      "hash": "sha256-YykJUwJwl14MeBWfZc5dKipfLp6XAWM/M42VrMzUk/c=",
      "url": "_framework/Syncfusion.Blazor.Navigations.38kc0e4ssx.wasm"
    },
    {
      "hash": "sha256-hLLsGw4/JlCK5X+EKjN2R9p2h00MTjvyHZYaD7nMEdA=",
      "url": "_framework/Syncfusion.Blazor.Notifications.4i7yzc8nqc.wasm"
    },
    {
      "hash": "sha256-c6oRTOvFFmV500g5qr5OTLJDL8yiFLoJ+bg1pVLzgZg=",
      "url": "_framework/Syncfusion.Blazor.Popups.j8k0c6yjvg.wasm"
    },
    {
      "hash": "sha256-TeExnlGdHBikDg3w1pgjKKu4+mCqE5zY+ACgbrOLZME=",
      "url": "_framework/Syncfusion.Blazor.Spinner.v1r33k0v4n.wasm"
    },
    {
      "hash": "sha256-082tzakkl179jiRnDd7CfZ44Wo6OnhiWyZmf+9S3uWo=",
      "url": "_framework/Syncfusion.Blazor.SplitButtons.p1334zx0gx.wasm"
    },
    {
      "hash": "sha256-1VnUmVMAeHwj+8MZzir7C7EBgWMAQIRCNPpOmoNofFY=",
      "url": "_framework/Syncfusion.Blazor.Themes.xxttdg7hkq.wasm"
    },
    {
      "hash": "sha256-X/m/DcFwNHOYdXker78QnC8IwNl2eZSkD0yNDq2TWPo=",
      "url": "_framework/Syncfusion.ExcelExport.Net.hkcsc79180.wasm"
    },
    {
      "hash": "sha256-q3JNoPP/owaBfR7Z8nR9yOvjq/Tw8Mxu6crk9LDeMO4=",
      "url": "_framework/Syncfusion.Licensing.l8q6nfr02m.wasm"
    },
    {
      "hash": "sha256-0LOynkVeYJilFTv6hymEOuWzwR38vYYEWBpKk42b74c=",
      "url": "_framework/Syncfusion.PdfExport.Net.stsl74x7bc.wasm"
    },
    {
      "hash": "sha256-WjRTeSJEprZ9HBzk4BKplWRIfgrhjPFFDj+UqA8cVrQ=",
      "url": "_framework/System.AppContext.69xw87cqtg.wasm"
    },
    {
      "hash": "sha256-3j3RX7ELLcTNnVgSKL/nQIF30UYXsmMglc/qhGDs75s=",
      "url": "_framework/System.Buffers.m3enj6d62j.wasm"
    },
    {
      "hash": "sha256-K4wiHreDko1fwGzNJheQz9DbCK4V+HUsGQuyuuSquBs=",
      "url": "_framework/System.Collections.Concurrent.7xcnvnvfe7.wasm"
    },
    {
      "hash": "sha256-M/IZfhSsVdt09D9vqi6G+5jmZwKwnpmoj80YhEqNmio=",
      "url": "_framework/System.Collections.Immutable.3gjnwcmszy.wasm"
    },
    {
      "hash": "sha256-cNYWf2QGLEhkh5iK07aMMe5Bcs3eS4UlF8l4/vYhrak=",
      "url": "_framework/System.Collections.NonGeneric.wor57912gd.wasm"
    },
    {
      "hash": "sha256-Gt60ISo8L7jUrF1s550/CSgDvoJ7dcEd1P2muR6WDf8=",
      "url": "_framework/System.Collections.Specialized.6wmcrebyv4.wasm"
    },
    {
      "hash": "sha256-EBK0m0SABO/x1RRnnH5vP69b6zfq2LdCOsOsVDlov64=",
      "url": "_framework/System.Collections.k7eocx66k5.wasm"
    },
    {
      "hash": "sha256-V2T0KVH8VVLw7L85hEgfeaEos1rJhvnYB3u9FIZmUPU=",
      "url": "_framework/System.ComponentModel.1er4s7iwhi.wasm"
    },
    {
      "hash": "sha256-XGeWQDi2iTnZBVzhCrGlittZAIdfUhrIbXRnpkhb028=",
      "url": "_framework/System.ComponentModel.Annotations.w9cu337rh7.wasm"
    },
    {
      "hash": "sha256-5g8drc35NLzT0Lyub4LojCNKfvdPO4MnDV+MM2bNL3Y=",
      "url": "_framework/System.ComponentModel.DataAnnotations.q4j9ve32z8.wasm"
    },
    {
      "hash": "sha256-En/nVKvNuqUTMc1tzWAdlyIevyeAxBtvc4xM9/MJuAc=",
      "url": "_framework/System.ComponentModel.EventBasedAsync.6j6cjcru2p.wasm"
    },
    {
      "hash": "sha256-q/oKLBvJG+geL5EyEHp2eXfgNhZVr/Zhi/FntEAwhQ0=",
      "url": "_framework/System.ComponentModel.Primitives.nl2ixrxcp7.wasm"
    },
    {
      "hash": "sha256-ChgNcQf/RB+Co51s8Ugh60AgiwQs/7h4eYcY4iFZoAY=",
      "url": "_framework/System.ComponentModel.TypeConverter.yl273bvsmt.wasm"
    },
    {
      "hash": "sha256-rQCrGK5wobGc3Hp+4oCT/3luV4uZhhHYY64s3eyYINo=",
      "url": "_framework/System.Configuration.zc0ilizti4.wasm"
    },
    {
      "hash": "sha256-JLvbJQwbzXWLPcuAap3mP40auHr8SAFCdxwW1pvdg9Q=",
      "url": "_framework/System.Console.c87d7usqgw.wasm"
    },
    {
      "hash": "sha256-4uVaLtcvzHPn/4NQ7CAdQS5YvEXAgPlK20cTabVAzLc=",
      "url": "_framework/System.Core.eovbtmx9ej.wasm"
    },
    {
      "hash": "sha256-3oNnHAFrSjx4eG9cQad/ekNH1TDn5kh/h81TGTrzFBc=",
      "url": "_framework/System.Data.Common.i3ihuk6o50.wasm"
    },
    {
      "hash": "sha256-CW8OHC3xmWQsCWFz/ONW6I+pGnoGJghtsPvfovvn4Lk=",
      "url": "_framework/System.Data.DataSetExtensions.drrqo6rbpu.wasm"
    },
    {
      "hash": "sha256-pQefGURvVYnJfB4r1bqwjICELx1/PcaO4X6DE2GmHqA=",
      "url": "_framework/System.Data.rwg7jt2c7s.wasm"
    },
    {
      "hash": "sha256-dP0J9QfyU79fjnu4R7pBWqThLAGFljYB+iZ4qD3my2g=",
      "url": "_framework/System.Diagnostics.Contracts.8nb2a3iwdt.wasm"
    },
    {
      "hash": "sha256-UIoVmBzWqal6zr8bfGgH31ABpMy0RtSpAH410LivWxw=",
      "url": "_framework/System.Diagnostics.Debug.shhvs5h51d.wasm"
    },
    {
      "hash": "sha256-eX6QyBIHo7DpqgE+zLLvIUsRKS0F3lcMDGJqx/bH+i0=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.v6xqrblgfp.wasm"
    },
    {
      "hash": "sha256-IE/nm8ILVpMsi9M5b/wHjl+hZ1mq8A80cBfrrDfIPQo=",
      "url": "_framework/System.Diagnostics.FileVersionInfo.4f475qbfex.wasm"
    },
    {
      "hash": "sha256-ctAOTzX6sRJrYmm6L1IR1d/peO/41z15KSvX5bD3CXA=",
      "url": "_framework/System.Diagnostics.Process.6bewsddwg5.wasm"
    },
    {
      "hash": "sha256-HlK7hkrTKLL/GWZNaNxHpN0Cq+jfxoRmxyQC6V8GNFY=",
      "url": "_framework/System.Diagnostics.StackTrace.ailofr3xg4.wasm"
    },
    {
      "hash": "sha256-wkyd1vycGAFwraqTTFaliZHidaWRULoFLWTA9TXUIUc=",
      "url": "_framework/System.Diagnostics.TextWriterTraceListener.y0i2x9wcx8.wasm"
    },
    {
      "hash": "sha256-QyVSWNwVykbkYBK62ib1bVRMckJ4VrKwTh20cbUKHaI=",
      "url": "_framework/System.Diagnostics.Tools.xv4owfjv5r.wasm"
    },
    {
      "hash": "sha256-FvewqTBqpx1JkQzNIlyVGAqjci3QNBorU1FMP20383A=",
      "url": "_framework/System.Diagnostics.TraceSource.qvejter5tv.wasm"
    },
    {
      "hash": "sha256-S79g7dYCezxrMalL8q9cDdrXnsjWlJ8eEfkkAoQiCUw=",
      "url": "_framework/System.Diagnostics.Tracing.vjwiyy6ngo.wasm"
    },
    {
      "hash": "sha256-J1BzaGslK1b041LKijGsbgEXo2hz+TV5aDeEDluHRLM=",
      "url": "_framework/System.Drawing.Primitives.1qn7cohx2f.wasm"
    },
    {
      "hash": "sha256-C5aie7lp5Olga/uM7+TxmJqlNqhGVdM0EnPkKvIPFzY=",
      "url": "_framework/System.Drawing.rccadbk353.wasm"
    },
    {
      "hash": "sha256-VP+X94eHpfTx68Wy9SWPtuwtQ9dkw22EM4flKmBKgR4=",
      "url": "_framework/System.Dynamic.Runtime.ck56btm7q7.wasm"
    },
    {
      "hash": "sha256-RnU0WJm52F6WBniZO9X8zK2po0C5dbfx9vtPn1JhTKk=",
      "url": "_framework/System.Formats.Asn1.y2x54k0om0.wasm"
    },
    {
      "hash": "sha256-E66k4j+pTfrMejgFxpuLwnZTMZmDPu9nRcYQBaUAhcI=",
      "url": "_framework/System.Formats.Tar.twtiqgxl95.wasm"
    },
    {
      "hash": "sha256-o0Mo6b0POvywYBd38GFQHye+xiFLumyyjq1QCfcP93s=",
      "url": "_framework/System.Globalization.Calendars.toi3bgped5.wasm"
    },
    {
      "hash": "sha256-a4TI7+ZAA4OWD0AVG1hk5BftP5bS+9NGN3gFf5j/pxI=",
      "url": "_framework/System.Globalization.Extensions.tmi9prr4h8.wasm"
    },
    {
      "hash": "sha256-/gSgB6F7rRQvM+yjhAiINKW0c5yWWJMv2oRozGSqRck=",
      "url": "_framework/System.Globalization.adywr1r9bu.wasm"
    },
    {
      "hash": "sha256-Z5CDkVkjwuT22en4OfKGOsKF8xmn3rnzpFC/sOV/s98=",
      "url": "_framework/System.IO.Compression.Brotli.xqt090n7fe.wasm"
    },
    {
      "hash": "sha256-sJvT36EkkK+tNHmjJH8bmlN6cc4/jQSoj8DmZvRK7Z0=",
      "url": "_framework/System.IO.Compression.FileSystem.8a6edcjpz8.wasm"
    },
    {
      "hash": "sha256-ZPFVvgHctccilTSA+aw7ptEIFAGSsK8OU2sqiWJnMtE=",
      "url": "_framework/System.IO.Compression.ZipFile.0h0gr0lp29.wasm"
    },
    {
      "hash": "sha256-U7uFERAexPQqzVn1O+j2wXcvfd0Z3iME+2TQyMw2VqE=",
      "url": "_framework/System.IO.Compression.r2vc7bedoc.wasm"
    },
    {
      "hash": "sha256-xlSHVtG4unz+dcAA0hhkA8Q0lHuSQNO66T03cCsDetU=",
      "url": "_framework/System.IO.FileSystem.AccessControl.q8w04p4lkj.wasm"
    },
    {
      "hash": "sha256-akbvdz+Bzo/lxy7wn9exx5ZIibbC/7Y613KCYeKsDcQ=",
      "url": "_framework/System.IO.FileSystem.DriveInfo.21bnaui2ta.wasm"
    },
    {
      "hash": "sha256-Wn6JJ3fC/tyCdCf8U8Z3CQEyS0acc7ycnOnWrefm7jc=",
      "url": "_framework/System.IO.FileSystem.Primitives.uai8nn8fsl.wasm"
    },
    {
      "hash": "sha256-RYe+cfmj735vWHHAgyNpM1DTaho0ZkUPa/PMmJv0BPM=",
      "url": "_framework/System.IO.FileSystem.Watcher.lohvs8m8cz.wasm"
    },
    {
      "hash": "sha256-HCMsOFWOEfPI6DaByEf17abUsIu2I7kmee0hPmPuVkk=",
      "url": "_framework/System.IO.FileSystem.ci93a4roia.wasm"
    },
    {
      "hash": "sha256-s25hyXaZ5uk3hvmTwFbYpW5EPpdPxcJDp/7iXCS2r7k=",
      "url": "_framework/System.IO.IsolatedStorage.z0ha6lo11a.wasm"
    },
    {
      "hash": "sha256-vocytJ/l6QXPGlQrcB0KK2aIqpQEzrohL48uGjcMQfA=",
      "url": "_framework/System.IO.MemoryMappedFiles.2kvmbxu1mj.wasm"
    },
    {
      "hash": "sha256-20bG9oqY9dw5UXZJXXmWUeUZKZagM6yyrp4uDMaWb3Y=",
      "url": "_framework/System.IO.Pipelines.frsl2omn10.wasm"
    },
    {
      "hash": "sha256-voPLo6JDiECfeenKIEHmLqv/qKABH50wlsdzt9VpyBI=",
      "url": "_framework/System.IO.Pipes.AccessControl.mrms2eewly.wasm"
    },
    {
      "hash": "sha256-6FSiZxMZg9eihpN7EPbxlmzXVzgpqbvSo/hr1TQWiKA=",
      "url": "_framework/System.IO.Pipes.wadz9p1757.wasm"
    },
    {
      "hash": "sha256-ry3N3SYpf2rcSD2fElLG2SmgLYCNER5QGACExKUqMMA=",
      "url": "_framework/System.IO.UnmanagedMemoryStream.5nttvixer4.wasm"
    },
    {
      "hash": "sha256-RnP1Vw/g7QXgQo0beNIQRUpJqm+Zdq+a9n5FD5FVhmg=",
      "url": "_framework/System.IO.ujr9p4dm3m.wasm"
    },
    {
      "hash": "sha256-J44ZD0+Abo5j1u9alQBOQSEv5QQwiuS9Bl11Hr1CyEg=",
      "url": "_framework/System.Linq.Expressions.n4kp8xrm7p.wasm"
    },
    {
      "hash": "sha256-wWwYZYO4PBLunTlKxgkgNrYf4LaRNLW1+ttyQNXRBrA=",
      "url": "_framework/System.Linq.Parallel.fk2xwub03l.wasm"
    },
    {
      "hash": "sha256-deNp98KQYru39BdpEEDVGJr5IgIF71vs8Awif2Roa18=",
      "url": "_framework/System.Linq.Queryable.npjr4r7hxc.wasm"
    },
    {
      "hash": "sha256-k/4vfd1gi0Igp02C6gO37W17kpB9ayyZ3n+wWGyw8j0=",
      "url": "_framework/System.Linq.bi0wcqo6qy.wasm"
    },
    {
      "hash": "sha256-6FFdAcFh1bU5oYaZPM8IawVzH2yuLUhZAUqU1H8GsNM=",
      "url": "_framework/System.Memory.80u0qc3eyv.wasm"
    },
    {
      "hash": "sha256-QECYQXIPSpm25jMOGqooUqHf1Yu9qZ1mqDu3jkixqZc=",
      "url": "_framework/System.Net.Http.Json.0slem1275q.wasm"
    },
    {
      "hash": "sha256-upfNQvzSBsRS8XQA3pe+w7ZM9LtVYVsPMBNSPQz0Za8=",
      "url": "_framework/System.Net.Http.md1bswe7tc.wasm"
    },
    {
      "hash": "sha256-XGqG7bZyewH40zhfml+ZSw2KL5zNmfw7FoZRvUxDBPg=",
      "url": "_framework/System.Net.HttpListener.o3q2lkyykw.wasm"
    },
    {
      "hash": "sha256-4RMFpDXMQyT4qhsQLpbiPCm7eDc2s5ialcC51zd/E3Q=",
      "url": "_framework/System.Net.Mail.r12nqubh1e.wasm"
    },
    {
      "hash": "sha256-/J0+R/iVUQOPv3kT6RUER/flByKyNSXkLo3/rUjOjaQ=",
      "url": "_framework/System.Net.NameResolution.wd9u3p7alm.wasm"
    },
    {
      "hash": "sha256-6IaMhqDl2A7hEWhohc+1Z7Rx9i05lnI1KrfQ47bru9A=",
      "url": "_framework/System.Net.NetworkInformation.wadfcrb4ng.wasm"
    },
    {
      "hash": "sha256-O2Mmei6iNrk3UtuXBlZNTo5s5nVxgj1Ftoo1lspinMo=",
      "url": "_framework/System.Net.Ping.j6du5khfyp.wasm"
    },
    {
      "hash": "sha256-exdvtma5pQ0+bTFtKFkM9UO1DoT/3/CoMtJ6alliEA8=",
      "url": "_framework/System.Net.Primitives.rog0rqelo4.wasm"
    },
    {
      "hash": "sha256-i1CgSScIo50IN6eB/MzFEuOfHqMlJ77qe40TWRmUQJM=",
      "url": "_framework/System.Net.Quic.bk3iyzagtw.wasm"
    },
    {
      "hash": "sha256-urm2huryfgDrvMw0MGd4tFTNfOidly7YLXdx4+mcNFE=",
      "url": "_framework/System.Net.Requests.yh0vmblcre.wasm"
    },
    {
      "hash": "sha256-mMC9pPuuxznXU4BiItV1X9W/yHL8ZcEuwyASbTRYcQo=",
      "url": "_framework/System.Net.Security.sr0ifz1ms7.wasm"
    },
    {
      "hash": "sha256-doTQB6fcYtyjN6poV0Fvvx0XvZvQ1FRelIayR3E1L38=",
      "url": "_framework/System.Net.ServicePoint.ii3nejp2xq.wasm"
    },
    {
      "hash": "sha256-9g7OESQMxFOhjJ3p+3DvempeXJkpt3ONvKlRglrSLS0=",
      "url": "_framework/System.Net.Sockets.2qi573rk74.wasm"
    },
    {
      "hash": "sha256-PsuK5MvKhguJJhG51ATXDsDvK6M388PkYmbY8SZdEBc=",
      "url": "_framework/System.Net.WebClient.6zl2dfdj87.wasm"
    },
    {
      "hash": "sha256-2pW9PMX+twt0ZEHlTyZiaS1AR32v/iuqAceMlhjzuwA=",
      "url": "_framework/System.Net.WebHeaderCollection.6toxm9clu5.wasm"
    },
    {
      "hash": "sha256-nZ6euTt/hGeNQZkfE4SNOefGQl252QLYMJj1PloKQ3I=",
      "url": "_framework/System.Net.WebProxy.zg8yqia6rm.wasm"
    },
    {
      "hash": "sha256-JUJbedL/7FtaJfk+Sz8Xq895L2A2G6sdox4mj9LWuvo=",
      "url": "_framework/System.Net.WebSockets.9v4eqey3ns.wasm"
    },
    {
      "hash": "sha256-0+eqZDo58c3c6D35LjE+ckKj1xd7lvHte+2fkTz8+VQ=",
      "url": "_framework/System.Net.WebSockets.Client.5ujv6fwlc7.wasm"
    },
    {
      "hash": "sha256-fR539S+bwSXVgp+3uaS1Q5U84NeEd9CRanORSCHCB2A=",
      "url": "_framework/System.Net.j0rb8fmqum.wasm"
    },
    {
      "hash": "sha256-yXp7bBpXpcNlAwM9S1VLSKU9L6AdD4WmhOHJ8rV2NxM=",
      "url": "_framework/System.Numerics.90814qnc69.wasm"
    },
    {
      "hash": "sha256-XfJBerh7sgb/6eKD6r6reMq8HWeYTih4l9cLZLkveeM=",
      "url": "_framework/System.Numerics.Vectors.zkzeaq78be.wasm"
    },
    {
      "hash": "sha256-cT7Oj8MIjjRPWoUXfWFhaX98I8Ja1euVw//7TAFSPFY=",
      "url": "_framework/System.ObjectModel.dpibji9kbk.wasm"
    },
    {
      "hash": "sha256-1OU1YKgOeX1+SJh4arMvQthG0Pk1cugP2GYSbyEBt08=",
      "url": "_framework/System.Private.CoreLib.gdne0axslz.wasm"
    },
    {
      "hash": "sha256-ODMTKHXU2ugKU1zWA3W35hBlu7RmiWiklaTSElV4hwc=",
      "url": "_framework/System.Private.DataContractSerialization.s7udpkt4m4.wasm"
    },
    {
      "hash": "sha256-NuUtr7v6SQnKsfv7AUGRWcM+y8fRpE7SdlWCxivyhqA=",
      "url": "_framework/System.Private.Uri.akbheibrxy.wasm"
    },
    {
      "hash": "sha256-Ohm3Iudl/LUOQvmww9wb/G9w6rb5MwQzSW/BmFI/nJE=",
      "url": "_framework/System.Private.Xml.2mep7n6yu4.wasm"
    },
    {
      "hash": "sha256-9dDKJVGHfc0p0O5c0ynqp+OIXcPyfaB4xh6KpoHa5UM=",
      "url": "_framework/System.Private.Xml.Linq.pznij1v87w.wasm"
    },
    {
      "hash": "sha256-Z7qYjBufHmw6kUBZchuFwV/8AhekqZ2u1JjPdNWsLc0=",
      "url": "_framework/System.Reflection.DispatchProxy.rz2l0yjrdh.wasm"
    },
    {
      "hash": "sha256-YsZ2JGMqM9ErPnTRKB418kzA1XeYpRIkEuVzwy0uTmM=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.ul9zb0sw6s.wasm"
    },
    {
      "hash": "sha256-gXgVmt9a/3wj1Xxib98T50wKaq67A7LO2sxhIJ7RVV8=",
      "url": "_framework/System.Reflection.Emit.Lightweight.h81142zbp5.wasm"
    },
    {
      "hash": "sha256-2UPd6E8YpQSfLB3NyFXZTMdWvg0n7BOtHnNxWOp76vw=",
      "url": "_framework/System.Reflection.Emit.r3y2j8tf69.wasm"
    },
    {
      "hash": "sha256-tpIvL/S9/SB9javHKbsHL5fRcK9d3v4jH2cWRRzb2NI=",
      "url": "_framework/System.Reflection.Extensions.q3j8knzs2x.wasm"
    },
    {
      "hash": "sha256-dseZsLBukxyc0//EfBZle+byG75lKChrUH30tET8uSQ=",
      "url": "_framework/System.Reflection.Metadata.act044hy0s.wasm"
    },
    {
      "hash": "sha256-JVg2JH92HegcOa0XYIW4JEA9CdQXoDf30w7RglipcDY=",
      "url": "_framework/System.Reflection.Primitives.5os0vainak.wasm"
    },
    {
      "hash": "sha256-6ZM+J2vC1ewu4NrAJ3pDfXjcBEXOkFcdwZCKwFYRYD0=",
      "url": "_framework/System.Reflection.TypeExtensions.5p21krjfml.wasm"
    },
    {
      "hash": "sha256-GfOsodQI4RuaJ/V5w8bS9fY5s6fAc/+hC+C+OhPOSU8=",
      "url": "_framework/System.Reflection.vmr4sf3lia.wasm"
    },
    {
      "hash": "sha256-RrOMh7Fflmijq+kQ00jqw+hn6YKo96iZKgXYaWaY6vA=",
      "url": "_framework/System.Resources.Reader.6dewscbl2z.wasm"
    },
    {
      "hash": "sha256-ULqJuTD0YgEEEQ6ME7LwaGEt4eO6NlKHmoWRQLiCkik=",
      "url": "_framework/System.Resources.ResourceManager.kvuwqbbhvv.wasm"
    },
    {
      "hash": "sha256-kSrZhHz5ja8JJXR7INSF31lKb7SxvyM1rY5YayEpsYA=",
      "url": "_framework/System.Resources.Writer.dpk7abvmmf.wasm"
    },
    {
      "hash": "sha256-ZR4rw0u/Tw7fNJarv8ioL1H7Zo/cUO3yEw1Hy6YO1z4=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.ja2wapc8ts.wasm"
    },
    {
      "hash": "sha256-2xr1KCucnlhi+ib0AjfdE3a3Z04EoMvadyD7Nlbe1x8=",
      "url": "_framework/System.Runtime.CompilerServices.VisualC.b05mwug83r.wasm"
    },
    {
      "hash": "sha256-eDV+IESTRl9cmrIPccQ/fXMf6PvKgUIDxs5hvpl5ZW4=",
      "url": "_framework/System.Runtime.Extensions.wmorg0bfhl.wasm"
    },
    {
      "hash": "sha256-zB8IfdNrsbp7xC+qDTzx4hTgzN/gnXnqlFuPorF2KbE=",
      "url": "_framework/System.Runtime.Handles.wry3x7xspd.wasm"
    },
    {
      "hash": "sha256-KDoINFDRHJ8Pu5o1C1wBZI9SIda7PKLmI92LfK/VEIk=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.gm4fhld22q.wasm"
    },
    {
      "hash": "sha256-IntHanIWOD/SnrE+/goZbhkKVnO1iL9VNK861YMZiiM=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.u8mdnzb9vy.wasm"
    },
    {
      "hash": "sha256-dG7GAKHV18AMGSeSQSV5kd3WieLFUB22pbNllS3npew=",
      "url": "_framework/System.Runtime.InteropServices.wtgp5mxw1c.wasm"
    },
    {
      "hash": "sha256-WOCZnZQcexMnzsRTroMKLUyq/pq3J2RJqta+QanxkCM=",
      "url": "_framework/System.Runtime.Intrinsics.gi0f477zy4.wasm"
    },
    {
      "hash": "sha256-fO8rRwIMpfZDabxoEYHjXA9AsDnmlART3gQkHg9417w=",
      "url": "_framework/System.Runtime.Loader.cot9lfqma4.wasm"
    },
    {
      "hash": "sha256-zBdVFvwwLKbv0DjVXFxri+BAsnJKz2dWVhQYeUFeHL4=",
      "url": "_framework/System.Runtime.Numerics.g9u8d42zol.wasm"
    },
    {
      "hash": "sha256-pYfVu7e9S5oGlsuuEssQVg86KJMiYI+Si78gZbHxU6U=",
      "url": "_framework/System.Runtime.Serialization.5wmrv335ba.wasm"
    },
    {
      "hash": "sha256-TBSKF9cAB8dfUpoI2ph//Xiy8Vi5NYb/E3qwccD8+Ws=",
      "url": "_framework/System.Runtime.Serialization.Formatters.8lhd6xdb7k.wasm"
    },
    {
      "hash": "sha256-04xP70ZHRi5gpY+QtvRHGHuD2wqMMDUeRtOu9b7oPJE=",
      "url": "_framework/System.Runtime.Serialization.Json.z0nxu35yve.wasm"
    },
    {
      "hash": "sha256-91fq6cGgCr9G+mlI+su/+6Uf/vJnjsxtMmGGybgSMjc=",
      "url": "_framework/System.Runtime.Serialization.Primitives.fqg5015ygf.wasm"
    },
    {
      "hash": "sha256-2qTmn0CJYKEr0Ula7cxW5UYUCZQGwznx0R3A6RwVrE8=",
      "url": "_framework/System.Runtime.Serialization.Xml.u3xtkxm1k9.wasm"
    },
    {
      "hash": "sha256-JLkVxBaclpeLsQ5jyDuBsosw6/tNfPcSJWx9/v4oxuM=",
      "url": "_framework/System.Runtime.grclbqoc80.wasm"
    },
    {
      "hash": "sha256-uHj8uCh7gsZJRIiF023EV4GXlZf8BLL2zf6mRUEZY0g=",
      "url": "_framework/System.Security.88p4kjqbas.wasm"
    },
    {
      "hash": "sha256-oSt7GqHO5j0KeGCDv1+2Su1MH3h463L7e5ubBQIzaow=",
      "url": "_framework/System.Security.AccessControl.pe5x2sidyv.wasm"
    },
    {
      "hash": "sha256-kaulak1+AChe7FZMy9qT8DS3Dp5SY2lNCFhjaif/X+c=",
      "url": "_framework/System.Security.Claims.l7kx3xked0.wasm"
    },
    {
      "hash": "sha256-RCXyoYas3cGys3td0sG0HXP8Q/pI8BuaYU38BRgpT2M=",
      "url": "_framework/System.Security.Cryptography.Algorithms.8lolrkmttk.wasm"
    },
    {
      "hash": "sha256-aVoAx87qwSo1iTzQO2QDDCl1tEgK1tPhQtUTWhgYWwY=",
      "url": "_framework/System.Security.Cryptography.Cng.xy0ipfnjac.wasm"
    },
    {
      "hash": "sha256-y71Kg/w5QM+RIchoXukhVxo9x8OewOEoMs6hP7sFIm8=",
      "url": "_framework/System.Security.Cryptography.Csp.tqrnaro11n.wasm"
    },
    {
      "hash": "sha256-wRkq0w5ZiZoPw3mSWtMUEc6KaZ7AWQgmerc5leDnYtM=",
      "url": "_framework/System.Security.Cryptography.Encoding.dxlnja37bj.wasm"
    },
    {
      "hash": "sha256-vptjZ6FgtgBPauumyfJ48l86KdO7HnQ8MTeWkwX59jw=",
      "url": "_framework/System.Security.Cryptography.OpenSsl.uk9h1gfypt.wasm"
    },
    {
      "hash": "sha256-nDAcS03VxsiiIXZU6Zc48rZooO3R/mdo0cnqGFwPbaM=",
      "url": "_framework/System.Security.Cryptography.Primitives.wxqgbuw71m.wasm"
    },
    {
      "hash": "sha256-vkTUHeFSGAgA8+FmseRWLnZ6itnUbq60eMHaRGsS9yQ=",
      "url": "_framework/System.Security.Cryptography.X509Certificates.m2ilqf86hj.wasm"
    },
    {
      "hash": "sha256-JomzotZvKj3Dswxo92Ft8TgIBTE+bSBHUHzSO94CyzI=",
      "url": "_framework/System.Security.Cryptography.qo6wt0x95a.wasm"
    },
    {
      "hash": "sha256-qVN02cdyGwF/laDjXCMxeUXo8c3+HMtpbtvt4lf7wKY=",
      "url": "_framework/System.Security.Principal.Windows.ldo9869o7b.wasm"
    },
    {
      "hash": "sha256-aS9n//VXqMcPHVRugjy8oRiV7Qy0GeJt0CXDYjUGwLI=",
      "url": "_framework/System.Security.Principal.l5y65m8m2t.wasm"
    },
    {
      "hash": "sha256-nHx+cm5lbMBhBIY54L1XsTe0OX2XgrjBket4/hldcVc=",
      "url": "_framework/System.Security.SecureString.c87gsi9tp6.wasm"
    },
    {
      "hash": "sha256-2sEk/ECeFrjUa73QWh/9S+yk1E+57Y4MQ4GVirnvwSs=",
      "url": "_framework/System.ServiceModel.Web.64psc55341.wasm"
    },
    {
      "hash": "sha256-bVu/ZX1HolbMf8KYDRkTB6uEvBDL2BWiD1Sr+z7fjdI=",
      "url": "_framework/System.ServiceProcess.j0wagton1u.wasm"
    },
    {
      "hash": "sha256-neeJgRHQESp95X4VYmYau9ADi9gRfzLdVrZD+20Lr5k=",
      "url": "_framework/System.Text.Encoding.CodePages.17ak399x9u.wasm"
    },
    {
      "hash": "sha256-RzEmC3krVLJ9ntQtDPb5biOo+VMRJQ9yXNpUldEUCgo=",
      "url": "_framework/System.Text.Encoding.Extensions.31quu9rg9b.wasm"
    },
    {
      "hash": "sha256-MxhxRj/3AtAjRI+NFH3TE1wDRsHrk2v16O9FV6yZGvA=",
      "url": "_framework/System.Text.Encoding.ruq9wa2av8.wasm"
    },
    {
      "hash": "sha256-iIgCDUHNaA7yZoPd5RuId5obZjiurjXH0SWZuCC2Ffs=",
      "url": "_framework/System.Text.Encodings.Web.ktp7ll9vtg.wasm"
    },
    {
      "hash": "sha256-AHlwCaYDyvvPiMc986YUKLoiaRYL7ph8kxiFqDW6Oqk=",
      "url": "_framework/System.Text.Json.spqbvbiy0p.wasm"
    },
    {
      "hash": "sha256-q31YShSwQTVUMkC6qPLL1cnolkqwgzaZpc1FyGUv8Bo=",
      "url": "_framework/System.Text.RegularExpressions.j6wzkfckdc.wasm"
    },
    {
      "hash": "sha256-Qns/dqTUF7fi5EGOXEeB7CtMsLhDYV3Q+hDRgg9OpRM=",
      "url": "_framework/System.Threading.Channels.eotefikzu6.wasm"
    },
    {
      "hash": "sha256-Rk+MnPULAL/QWvLXQmRK/KQ78DstK3HKj++2//yHJfE=",
      "url": "_framework/System.Threading.Overlapped.qsv3dgk98d.wasm"
    },
    {
      "hash": "sha256-3p9vchw1uDGQfZ6IKA2Aad61OGaKHJDpSHfx1xFffy0=",
      "url": "_framework/System.Threading.Tasks.Dataflow.qux3elp3sq.wasm"
    },
    {
      "hash": "sha256-6a4BSm0nYOWOSiERCmoNDZrFWTFZtesahBeD0sG+Zco=",
      "url": "_framework/System.Threading.Tasks.Extensions.bz6v4y1bgr.wasm"
    },
    {
      "hash": "sha256-weCM97M0KzlvPfFgYLMYqH/amjcQobpW4qlZL3qxo4k=",
      "url": "_framework/System.Threading.Tasks.Parallel.pia6qfjdvy.wasm"
    },
    {
      "hash": "sha256-K3c/ZIRTSn0oh1TmAg8UwOACCWFTQE0NYxB+3eFoaQQ=",
      "url": "_framework/System.Threading.Tasks.zmf0gmcpmv.wasm"
    },
    {
      "hash": "sha256-iPMgw0rb/TzX741+abHRk7NbjO0UOglDram06lov+VI=",
      "url": "_framework/System.Threading.Thread.k53q2qtn4x.wasm"
    },
    {
      "hash": "sha256-c12BCOrRh3kc02i1rTPs93xFibEd8h3usb6B0qvgeWg=",
      "url": "_framework/System.Threading.ThreadPool.vtcexxwpo3.wasm"
    },
    {
      "hash": "sha256-f+FrWYx/21P3Y9NQ7Nqnd3vHSh3V7mpfUh9yFGQh6wA=",
      "url": "_framework/System.Threading.Timer.5bvshcz8rs.wasm"
    },
    {
      "hash": "sha256-5vw+LhiGIokAb9t63BXU11cpyu2frC81SvsrWbUixvU=",
      "url": "_framework/System.Threading.mghm3mgo9q.wasm"
    },
    {
      "hash": "sha256-ZAqca2tkqMy6m4t15kYxaz6IJq9TwpbleftIIh24yq0=",
      "url": "_framework/System.Transactions.0vkshbqlor.wasm"
    },
    {
      "hash": "sha256-bhoU1a5vQrWuSKJVb+I4gc9eFzSZc7w4S+Hnuetxl1s=",
      "url": "_framework/System.Transactions.Local.upfcz2s4al.wasm"
    },
    {
      "hash": "sha256-r8gRxNTnP1GwHsOms7P8xf8UZzdH6qfICNkcGRIZhyg=",
      "url": "_framework/System.ValueTuple.96vy1hi31v.wasm"
    },
    {
      "hash": "sha256-mH31oNYw5+UG49dSlm838uP1UfXQGtpAsCVyz848FfY=",
      "url": "_framework/System.Web.HttpUtility.crconwjg8e.wasm"
    },
    {
      "hash": "sha256-GruUFtvDlkfkAm3+9ubzpIlckp0tVds/U4BTtZ/uT38=",
      "url": "_framework/System.Web.i52kdwx1wz.wasm"
    },
    {
      "hash": "sha256-bTs5ogTfks55oP4Jbq1P0aiVrOQzsupL8G9KgznMnQ8=",
      "url": "_framework/System.Windows.pxvni61c5f.wasm"
    },
    {
      "hash": "sha256-nuyYbM7wJPWXqp3bQ5b+hxJYWd3snVgE108h4ZBqcEI=",
      "url": "_framework/System.Xml.Linq.qe9nkopg6h.wasm"
    },
    {
      "hash": "sha256-u956/ME4lyctNDenNsnhDYVGaMAyDbkGT3p1WRqN8fk=",
      "url": "_framework/System.Xml.ReaderWriter.7tqo9y1j7t.wasm"
    },
    {
      "hash": "sha256-Usq+mk/8/uKUboQSDMewX4BodqyEN1MImmkHWGFWxJA=",
      "url": "_framework/System.Xml.Serialization.m25ww1xmlb.wasm"
    },
    {
      "hash": "sha256-qS25A4gDSTa0aOaka7XW3TuTJ2FQaDMw+tHAlkelEmY=",
      "url": "_framework/System.Xml.XDocument.b3qpy0ywdq.wasm"
    },
    {
      "hash": "sha256-gsrp2UsBOpo6DVsZu4ARBsWCm3JQPuNVXUQ+okp6R0A=",
      "url": "_framework/System.Xml.XPath.6zhyzqh2n6.wasm"
    },
    {
      "hash": "sha256-b6b4ScTgYcA196w5Fu47Y93t3RS0WF43M2zkxQjqZV4=",
      "url": "_framework/System.Xml.XPath.XDocument.7m1x4rd2b8.wasm"
    },
    {
      "hash": "sha256-ZuximY5G3R2IKy2kSInT0cpkNg1c1D1N+CiupL8+ZNo=",
      "url": "_framework/System.Xml.XmlDocument.q8ihts3lf6.wasm"
    },
    {
      "hash": "sha256-sEDsdRnHVbBNVz6bccuTQVGhvbDDG4FjUvsAs9JYWWk=",
      "url": "_framework/System.Xml.XmlSerializer.0sc0ourwbb.wasm"
    },
    {
      "hash": "sha256-1mUMJnO1XU6Oh74bHbj/CMBgsf1njzDYzjSkw3ZehSA=",
      "url": "_framework/System.Xml.ev8p5vqcxx.wasm"
    },
    {
      "hash": "sha256-9pVBpQZbLwdDpJKVVwy9ZdzXAR66hfWXuyiJRIkhaUM=",
      "url": "_framework/System.uey7cwmupp.wasm"
    },
    {
      "hash": "sha256-BgyZxTgdU9rIYlNC9ZMiMjnvBAJSL0eQH8Y87o1M+q4=",
      "url": "_framework/WindowsBase.ag32297siy.wasm"
    },
    {
      "hash": "sha256-vFzuWkxrPC3MPDPp6fANpqGmyUojp2IUC+rObJuXcaI=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-XoL4KXKUiNydxBQ0q7b/0gDsgsuq8oac0YMVUnGkfRc=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-hZR53FKJSxjnxgvKrH7p+D7FLbv31p/Msx6rLNsW5Ps=",
      "url": "_framework/dotnet.js.map"
    },
    {
      "hash": "sha256-1UPiprzN3JhPftx3be7XEMaYlUN+chRF41CuttiWVtQ=",
      "url": "_framework/dotnet.native.1p93gcv9fh.js"
    },
    {
      "hash": "sha256-Yaw09m1FVxsROJ5Sa9f6SmuJebQT0b3hrKQIbo6qm5A=",
      "url": "_framework/dotnet.native.9msu8ucn2h.wasm"
    },
    {
      "hash": "sha256-j0o3Jd43TEt7CL/kaSWnO8IALA8Zgoa3fcyaWDAVIyM=",
      "url": "_framework/dotnet.runtime.js.map"
    },
    {
      "hash": "sha256-ilTXrnUF4HKbIAFVIYlRmX3ryKNZpGUObkWMF0n2Kcg=",
      "url": "_framework/dotnet.runtime.qrl1fuqt3c.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-/aFxOaPc1iTNlJw0z4/RGEMD0nzl4qVE3SF4wMsLgp0=",
      "url": "_framework/mscorlib.vt9pwshhot.wasm"
    },
    {
      "hash": "sha256-nD1KqAI5YYz+YohqHaZ5EmXi7Eq9Uy9sUknnI8sj1AM=",
      "url": "_framework/netstandard.or41gtprh3.wasm"
    },
    {
      "hash": "sha256-kDPqmz8DSpaGaQfLHl/NOQgV+xCChhtrBrVanIccJh4=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-vGbjgqEqv4y3q5OB8W2R9LthkuF8mQfHFeNdKSReSmU=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-0IPgeEKDZCFrUQcpdCtliZtA1wAO2n825Gw7mh0U6bU=",
      "url": "images/logos/logo_oxid.png"
    },
    {
      "hash": "sha256-dKhmfhElbM2mIaSDdy8gM6FyYObEMYzZuloGMC+nqfg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-mEPPh2jO9zwHGL0Pse28aob93lKJeY9HlQT9LHl46LQ=",
      "url": "js/imageHelper.js"
    },
    {
      "hash": "sha256-f4c8YV1qrr6RSiVYWMQT7R5W2OkT+iXmE5H69/uRvGQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-hN2ttMG/K3wQlFrN3SbQ1YF4tIJHCE4oYP+QibT3vOY=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-M15fHTKfMK6cTars5c28PNhN6hD0qeUb3HPzOdoPwCc=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-+rGG3u63SMkHL80Ga42LAawPUj7i8vaR2Kuenqlta2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-rjusxCRzKjztCcfgOVduAc3e3Z7KvimJGokJSeADNmE=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-y72bT5TKmFmfvw3bNEzPRNZa/8595xtseZIcBUV0PdM=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-gRKIHVkBgnCPUs/hmZsXynZ9ZJpvsE77idtljDkrWGI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-UkajePbMzGj8y73Imkd3dWWnLJr0v2CrBCLMrVMleP8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-uIzOR4gILoNjCGNryIsWnkEGO3BSwRa/MLjr73tDodE=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-ZBXbYF8OZrF1GDOLMLvW/zRPtx1RfeMDYj5D2Wb/9jo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-MwFckg8YbY2WrveNQnXkfULkprYhFOq+t1BH92A7GsI=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-7MYEMUFgHEc1CjrfAK/TlV30POxgoxXk2b+vAs/143U=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-CzmECrtXV8BSk/+8SG+Rw7Fr+3hCt2bS2bEkS4YD3PQ=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-sKIQRfQriISuQ9l/44b1zHfQniGXJhGonVtB2LlSuIs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-/rceNUMI0RlFJugRzjua815bgXwawEJBGBPh4Vx3r38=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-rI1w2GDxZPCr77bpZIGQ8mUvMVtEr+gBtahl5RIPJpA=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-tfvTZJ9THBSrf9AiDOw1e1OCTTezYFzVq/qdR+Xt1bE=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-Zkt8V4XVeuL3beV7qDclhQ4wsMqOChoFJOnke/YFaUc=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-6zfk2L8R3wCgRbZzpkEi7UYC2bc6fYGIgFfNeqyOWnQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-/8RGRWLHnGrvlFSAStfOZtdhR4B59TBmRrvl3ys69fs=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-Nx1P/IOn7PBKl9EOL02HoUx8NB4ZV2Z3ppGQ5AGHcWs=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-nqAVDyO3GozgiMoeqGwM46qII+AVfQ/ygQA4KClfKL0=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-REjSeieVKd00nAKwd6dv7MMhuVKvKctPmLI4iDRs/cc=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-CHaC+VUdQSi16lFnH//iT1FoVbgF25ns1CkzoNFeSEA=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-cRQGt9Q6vLHZ366VYP1lab0tJzXpCG8j/8xmKa3aMxw=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-hUJvZpLft1hw2eVB/dTTdi6QHSjBADTGhBQnX9TN+34=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-aCTIqw9op0XQGYnNe1649V7fnihACD48OP3M8BP2xVM=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-627Db8/21XaFvn0TtgCHioMb9U4gZ3D94V/isvgpbpc=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-6a0fHv4pDg1hZEHKMIbYGOQEvkWexdYcpWbS3vza0X0=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
